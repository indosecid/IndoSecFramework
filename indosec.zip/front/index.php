<?php 
	
	include 'version.php';

function printIndex()
{
	print "
                                       
 IndoSec Framework Tools @ { IndoSec Coder Team } \n
 Version : ".$version."
 \n\n";
 
print "
 *Scanning : {
	1 : Nmap, 2 : DNS Loockup, 3 : Host Search, 4 : ReverseIP, 5 : Whois
 },
 *BruteForce : {
 	6 : AdminFinder, 7 : Dir Scanner(Builder), 8 : SubdoBrute, 9 : LoginBruteForce
 	23 : Shell Scanner
 },
 *Encode&Decode : {
 	11 : EncodeString
 },
 *Tracking : {
 	20 : GPS Tracking, 21 : IP Tracking(Builder)
 },
 *Spam : {
 	13 : Bomb Telpon, 14 : Bomb SMS
 }

 --help 	--about 	--version 		
\n\n";
}



?>
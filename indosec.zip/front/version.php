<?php 

$version = '1.2.0';

return $version;

?>